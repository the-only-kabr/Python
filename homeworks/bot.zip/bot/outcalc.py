#
#import calc
# from calc import *
# from inp import *
# myOutput(calculate(
# myInput(), myInput(), myInput()))